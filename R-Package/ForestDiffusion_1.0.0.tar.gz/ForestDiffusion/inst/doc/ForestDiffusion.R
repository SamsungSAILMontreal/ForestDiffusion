## ----fig.width=6, fig.height=6, eval=FALSE------------------------------------
#  library(ForestDiffusion)
#  
#  # Load iris
#  data(iris)
#  # variables 1 to 4 are the input X
#  # variable 5 (iris$Species) is the outcome (class with 3 labels)
#  
#  # Add NAs (but not to label) to emulate having a dataset with missing values
#  iris[,1:4] = missForest::prodNA(iris[,1:4], noNA = 0.2)
#  
#  # Setup data
#  X = data.frame(iris[,1:4])
#  y = iris$Species
#  Xy = iris
#  plot(Xy)
#  
#  # When you do not want to train a seperate model per model (or you have a regression problem), you can provide the dataset together
#  forest_model = ForestDiffusion(X=Xy, n_cores=4, n_t=50, duplicate_K=100, flow=TRUE, seed=666)
#  
#  Xy_fake = ForestDiffusion.generate(forest_model, batch_size=NROW(Xy), seed=666)
#  plot(Xy_fake)
#  
#  # When the outcome y is categorical, you can provide it seperately to construct a seperate model per label (this can improve performance, but it will be slower)
#  forest_model = ForestDiffusion(X=X, n_cores=4, label_y=y, name_y='Species', n_t=50, duplicate_K=100, flow=TRUE, seed=666)
#  
#  Xy_fake = ForestDiffusion.generate(forest_model, batch_size=NROW(Xy), seed=666)
#  plot(Xy_fake)
#  

## ----eval=FALSE---------------------------------------------------------------
#  # Use the real data to fit a GLM
#  fit = glm(Species ~ Sepal.Length, family = 'binomial', data=Xy)
#  summary(fit)
#  
#  # Use fake data to fit a GLM
#  fit = glm(Species ~ Sepal.Length, family = 'binomial', data=Xy_fake)
#  summary(fit)
#  
#  # Use data augmentation (equal real with equal fake data) to fit a GLM
#  X_combined = data.frame(rbind(Xy, Xy_fake))
#  fit = glm(Species ~ Sepal.Length, family = 'binomial', data=X_combined)
#  summary(fit)

## ----eval=FALSE---------------------------------------------------------------
#  library(missForest)
#  
#  # Normally, you would use missForest as follows
#  mf = missForest::missForest(Xy, verbose = TRUE)
#  
#  # Instead, you can now use data augmentation
#  Xy_fake = ForestDiffusion.generate(forest_model, batch_size=NROW(Xy), seed=666) # generates as much fake as real data
#  X_combined = data.frame(rbind(Xy, Xy_fake)) # combine real and fake data
#  mf_dataug = missForest(X_combined, verbose = TRUE) # train missForest with augmented data
#  

## ----eval=FALSE---------------------------------------------------------------
#  library(mice)
#  
#  # Generate fake data
#  ngen = 9 # number of generated datasets we want
#  Xy_fake = ForestDiffusion.generate(forest_model, batch_size=ngen*NROW(Xy), seed=666)
#  
#  # Make a list of fake datasets
#  data_list = split(Xy_fake, rep(1:ngen, each=NROW(Xy)))
#  
#  # Fit a model per fake dataset
#  fits <- with_datasets(data_list, glm(Species ~ Sepal.Length, family = 'binomial'))
#  
#  # Pool the results
#  mice::pool(fits)
#  

## ----eval=FALSE---------------------------------------------------------------
#  library(mice)
#  
#  nimp = 5 # number of imputations needed
#  
#  # Must train a VP diffusion model (instead of a Flow model) to be able to impute data
#  forest_model_vp = ForestDiffusion(X=Xy, n_cores=4, n_t=50, duplicate_K=100, flow=FALSE, seed=666)
#  
#  Xy_imp = ForestDiffusion.impute(forest_model_vp, k=nimp, seed=666) # regular imputations (fast)
#  Xy_imp = ForestDiffusion.impute(forest_model_vp, repaint=TRUE, r=10, j=5, k=nimp, seed=666) # REPAINT imputations (slow, but better)
#  plot(Xy_imp[[1]]) # plot the first imputed dataset
#  
#  # When the outcome y is categorical, you can provide it seperately to construct a seperate model per label (this can improve performance, but it will be slower)
#  forest_model_vp = ForestDiffusion(X=X, n_cores=4, label_y=y, name_y='Species', n_t=50, duplicate_K=100, flow=TRUE, seed=666)
#  
#  Xy_imp = ForestDiffusion.impute(forest_model_vp, k=nimp, seed=666) # regular imputations (fast)
#  Xy_imp = ForestDiffusion.impute(forest_model_vp, repaint=TRUE, r=10, j=5, k=nimp, seed=666) # REPAINT imputations (slow, but better)
#  plot(Xy_imp[[1]]) # plot the first imputed dataset

## ----eval=FALSE---------------------------------------------------------------
#  # Fit a model per imputed dataset
#  fits <- with_datasets(Xy_imp, glm(Species ~ Sepal.Length, family = 'binomial'))
#  
#  # Pool the results
#  mice::pool(fits)
#  

