## -----------------------------------------------------------------------------
library(ForestDiffusion)

# Load iris
data(iris)
# variables 1 to 4 are the input X
# variable 5 (iris$Species) is the outcome (class with 3 labels)

# Add NAs (but not to label) to emulate having a dataset with missing values
iris[,1:4] = missForest::prodNA(iris[,1:4], noNA = 0.2)

# Setup data
X = data.frame(iris[,1:4])
y = iris$Species
Xy = iris
plot(Xy)

# When you do not want to train a seperate model per model (or you have a regression problem), you can provide the dataset together
forest_model_uncond = ForestDiffusion(Xy, n_t=50, duplicate_K=50, flow=TRUE, max_n_cpus=4)
Xy_fake = ForestDiffusion.generate(forest_model_uncond, batch_size=NROW(Xy))
plot(Xy_fake)

# When the outcome y is categorical, you can provide it seperately to construct a seperate model per label (this can improve performance, but it will be slower)
forest_model = ForestDiffusion(X, label_y=y, name_y='Species', n_t=50, duplicate_K=50, flow=TRUE, max_n_cpus=4)
Xy_fake = ForestDiffusion.generate(forest_model, batch_size=NROW(X))
plot(Xy_fake)


## -----------------------------------------------------------------------------
# Use the real data to fit a GLM
fit = glm(Species ~ Sepal.Length, family = 'binomial', data=Xy)
summary(fit)

# Use fake data to fit a GLM
fit = glm(Species ~ Sepal.Length, family = 'binomial', data=Xy_fake)
summary(fit)

# Use data augmentation (equal real with equal fake data) to fit a GLM
X_combined = data.frame(rbind(Xy, Xy_fake))
fit = glm(Species ~ Sepal.Length, family = 'binomial', data=X_combined)
summary(fit)

## -----------------------------------------------------------------------------
library(missForest)

# Normally, you would use missForest as follows
missForest::missForest(Xy, verbose = TRUE)

# Instead, you can now use data augmentation
Xy_fake = ForestDiffusion.generate(forest_model, batch_size=NROW(Xy)) # generates as much fake as real data
X_combined = data.frame(rbind(Xy, Xy_fake)) # combine real and fake data
missForest(X_combined, verbose = TRUE) # train missForest with augmented data for higher imputation performance


## -----------------------------------------------------------------------------
library(mice)

# Generate fake data
ngen = 9 # number of generated datasets we want
Xy_fake = ForestDiffusion.generate(forest_model, batch_size=ngen*NROW(Xy))

# Make a list of fake datasets
data_list = split(Xy_fake, rep(1:ngen, each=NROW(Xy)))

# Fit a model per fake dataset
fits <- with_datasets(data_list, glm(Species ~ Sepal.Length, family = 'binomial'))

# Pool the results
mice::pool(fits) 


## -----------------------------------------------------------------------------
library(mice)

# Must train a VP diffusion model (instead of a Flow model) to be able to impute data
forest_model_vp = ForestDiffusion(Xy, n_t=50, duplicate_K=50, flow=FALSE, max_n_cpus=4)
nimp = 5 # number of imputations needed
Xy_imp = ForestDiffusion.impute(forest_model_vp, k=nimp) # regular imputations (fast)
Xy_imp = ForestDiffusion.impute(forest_model_vp, repaint=TRUE, r=10, j=5, k=nimp) # REPAINT imputations (slow, but better)
plot(Xy_imp[[1]]) # plot first imputed dataset

